def count_in_list(list, item):
    """Return how many times item appears in lst."""
    return list.count(item)