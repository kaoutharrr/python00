ft_package

A test package for counting occurrences in a list.
